"""
==============================================================
MÓDULO DE EVALUACIÓN — FASE 5 TFM
Sistema de Filtrado de CVs con IA Generativa
Autores: Juan Camilo Pedraza / Gustavo España Paz
==============================================================

Uso:
    python evaluacion_tfm.py --ground_truth ground_truth.csv --predicciones predicciones.csv

Estructura esperada de ground_truth.csv:
    id, nombre, label_binario (1=APTO, 0=NO APTO), ranking_humano, score_esperado

Estructura esperada de predicciones.csv:
    id, nombre, score_sistema (0-100), label_sistema (1=APTO, 0=NO APTO), ranking_sistema
"""

import json
import argparse
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from pathlib import Path
from datetime import datetime
from scipy.stats import spearmanr
from sklearn.metrics import (
    confusion_matrix,
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
    classification_report,
    ConfusionMatrixDisplay
)

warnings.filterwarnings("ignore")

# ──────────────────────────────────────────────
# 1. CARGA Y VALIDACIÓN DE DATOS
# ──────────────────────────────────────────────

def cargar_datos(path_ground_truth: str, path_predicciones: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Carga y valida los archivos CSV de entrada.
    Lanza ValueError si faltan columnas requeridas.
    """
    gt = pd.read_csv(path_ground_truth)
    pred = pd.read_csv(path_predicciones)

    cols_gt = {"id", "nombre", "label_binario", "ranking_humano", "score_esperado"}
    cols_pred = {"id", "nombre", "score_sistema", "label_sistema", "ranking_sistema"}

    faltantes_gt = cols_gt - set(gt.columns)
    faltantes_pred = cols_pred - set(pred.columns)

    if faltantes_gt:
        raise ValueError(f"Columnas faltantes en ground_truth.csv: {faltantes_gt}")
    if faltantes_pred:
        raise ValueError(f"Columnas faltantes en predicciones.csv: {faltantes_pred}")

    df = pd.merge(gt, pred[["id", "score_sistema", "label_sistema", "ranking_sistema"]], on="id")
    print(f"✓ Dataset cargado: {len(df)} candidatos evaluados\n")
    return gt, pred, df


# ──────────────────────────────────────────────
# 2. MÉTRICAS DE CLASIFICACIÓN BINARIA
# ──────────────────────────────────────────────

def calcular_metricas_clasificacion(df: pd.DataFrame) -> dict:
    """
    Calcula Precisión, Recall, F1-Score y Accuracy.
    Usa el juicio del reclutador (label_binario) como ground truth.
    """
    y_true = df["label_binario"]
    y_pred = df["label_sistema"]

    metricas = {
        "accuracy":  round(accuracy_score(y_true, y_pred), 4),
        "precision": round(precision_score(y_true, y_pred, zero_division=0), 4),
        "recall":    round(recall_score(y_true, y_pred, zero_division=0), 4),
        "f1_score":  round(f1_score(y_true, y_pred, zero_division=0), 4),
        "cm":        confusion_matrix(y_true, y_pred),
        "reporte":   classification_report(y_true, y_pred, target_names=["No apto", "Apto"])
    }

    cm = metricas["cm"]
    # Extraer TP, FP, TN, FN de la matriz de confusión
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        metricas.update({"TP": int(tp), "FP": int(fp), "TN": int(tn), "FN": int(fn)})

    return metricas


def imprimir_metricas(metricas: dict) -> None:
    print("=" * 55)
    print("  MÉTRICAS DE CLASIFICACIÓN BINARIA")
    print("=" * 55)
    print(f"  Accuracy   : {metricas['accuracy']:.2%}")
    print(f"  Precisión  : {metricas['precision']:.2%}")
    print(f"  Recall     : {metricas['recall']:.2%}  ← (crítico en RRHH)")
    print(f"  F1-Score   : {metricas['f1_score']:.2%}  ← (métrica principal)")
    print("-" * 55)
    if "TP" in metricas:
        print(f"  TP={metricas['TP']}  FP={metricas['FP']}  TN={metricas['TN']}  FN={metricas['FN']}")
    print("=" * 55)
    print("\n  Reporte detallado:")
    print(metricas["reporte"])


# ──────────────────────────────────────────────
# 3. CORRELACIÓN DE RANKING (SPEARMAN)
# ──────────────────────────────────────────────

def calcular_spearman(df: pd.DataFrame) -> dict:
    """
    Calcula la correlación de Spearman entre el ranking del sistema
    y el ranking del reclutador humano.
    ρ > 0.7 y p < 0.05 = resultado publicable.
    """
    rho, p_value = spearmanr(df["ranking_humano"], df["ranking_sistema"])
    resultado = {
        "rho": round(rho, 4),
        "p_value": round(p_value, 4),
        "interpretacion": interpretar_spearman(rho, p_value)
    }
    print("=" * 55)
    print("  CORRELACIÓN DE RANKING — SPEARMAN")
    print("=" * 55)
    print(f"  ρ (rho)   : {rho:.4f}")
    print(f"  p-value   : {p_value:.4f}")
    print(f"  Resultado : {resultado['interpretacion']}")
    print("=" * 55 + "\n")
    return resultado


def interpretar_spearman(rho: float, p: float) -> str:
    if p >= 0.05:
        return "No significativo (p ≥ 0.05) — aumentar muestra"
    if rho >= 0.9:
        return "Correlación muy alta — excelente alineación con el reclutador"
    elif rho >= 0.7:
        return "Correlación alta — resultado publicable para TFM"
    elif rho >= 0.5:
        return "Correlación moderada — revisar casos borderline"
    else:
        return "Correlación baja — el modelo no replica bien el juicio humano"


# ──────────────────────────────────────────────
# 4. ANÁLISIS DE CONSISTENCIA
# ──────────────────────────────────────────────

def analizar_consistencia(df: pd.DataFrame, varianza_scores: list = None) -> dict:
    """
    Experimento A: Invarianza de orden.
    Recibe una lista de scores del mismo candidato evaluado N veces
    con los CVs en diferente orden. Calcula la varianza.

    Experimento B: Robustez semántica.
    Compara el score original vs. el score con CV reformulado.
    """
    resultados = {}

    # Experimento A: si se pasan múltiples ejecuciones
    if varianza_scores and len(varianza_scores) > 1:
        arr = np.array(varianza_scores)
        resultados["varianza_orden"] = {
            "scores": varianza_scores,
            "media": round(float(arr.mean()), 2),
            "std": round(float(arr.std()), 2),
            "cv_pct": round(float(arr.std() / arr.mean() * 100), 2),
            "estable": arr.std() < 5  # umbral: desviación < 5 puntos
        }
        print("CONSISTENCIA — Experimento A (Invarianza de orden)")
        print(f"  Scores en diferentes ejecuciones: {varianza_scores}")
        print(f"  Media: {resultados['varianza_orden']['media']} | Std: {resultados['varianza_orden']['std']}")
        estable = resultados["varianza_orden"]["estable"]
        print(f"  Estado: {'✓ ESTABLE' if estable else '✗ INESTABLE — revisar pipeline'}\n")

    # Experimento B: diferencia de score por reformulación
    # Buscar candidatos con score original vs. reformulado (columna score_reformulado si existe)
    if "score_reformulado" in df.columns:
        df["delta_score"] = abs(df["score_sistema"] - df["score_reformulado"])
        resultados["robustez_semantica"] = {
            "delta_medio": round(df["delta_score"].mean(), 2),
            "max_delta": round(df["delta_score"].max(), 2),
            "robusto": df["delta_score"].mean() < 10
        }
        print("CONSISTENCIA — Experimento B (Robustez semántica)")
        print(f"  Delta medio entre score original y reformulado: {resultados['robustez_semantica']['delta_medio']}")
        robusto = resultados["robustez_semantica"]["robusto"]
        print(f"  Estado: {'✓ ROBUSTO' if robusto else '✗ FRÁGIL — modelo sensible a reformulaciones'}\n")

    return resultados


# ──────────────────────────────────────────────
# 5. VISUALIZACIONES
# ──────────────────────────────────────────────

def generar_reporte_visual(df: pd.DataFrame, metricas: dict, spearman: dict, output_dir: str = ".") -> None:
    """
    Genera un panel de 4 gráficas y lo guarda como PNG.
    """
    fig = plt.figure(figsize=(14, 10))
    fig.suptitle("Reporte de Evaluación — Sistema de Filtrado de CVs con IA", 
                 fontsize=14, fontweight='bold', y=0.98)
    
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.35)

    # ── Gráfica 1: Matriz de confusión ──
    ax1 = fig.add_subplot(gs[0, 0])
    cm = metricas["cm"]
    disp = ConfusionMatrixDisplay(cm, display_labels=["No apto", "Apto"])
    disp.plot(ax=ax1, colorbar=False, cmap="Blues")
    ax1.set_title("Matriz de confusión", fontsize=11, fontweight='bold')
    ax1.set_xlabel("Predicción del sistema")
    ax1.set_ylabel("Juicio del reclutador")

    # ── Gráfica 2: Barras de métricas ──
    ax2 = fig.add_subplot(gs[0, 1])
    nombres = ["Accuracy", "Precisión", "Recall", "F1-Score"]
    valores = [metricas["accuracy"], metricas["precision"], metricas["recall"], metricas["f1_score"]]
    colores = ["#B5D4F4", "#B5D4F4", "#5DCAA5", "#1D9E75"]  # verde para recall y f1 (más importantes)
    bars = ax2.bar(nombres, valores, color=colores, edgecolor="white", linewidth=0.5)
    ax2.set_ylim(0, 1.15)
    ax2.set_title("Métricas de clasificación", fontsize=11, fontweight='bold')
    ax2.set_ylabel("Valor")
    ax2.axhline(y=0.7, color="gray", linestyle="--", linewidth=0.8, alpha=0.5, label="Umbral 0.7")
    ax2.legend(fontsize=9)
    for bar, val in zip(bars, valores):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                 f"{val:.2%}", ha="center", va="bottom", fontsize=10, fontweight='bold')

    # ── Gráfica 3: Scatter ranking humano vs. sistema ──
    ax3 = fig.add_subplot(gs[1, 0])
    colores_puntos = df["label_binario"].map({1: "#1D9E75", 0: "#D85A30"})
    ax3.scatter(df["ranking_humano"], df["ranking_sistema"], 
                c=colores_puntos, s=80, alpha=0.8, edgecolors="white", linewidth=0.5)
    max_rank = max(df["ranking_humano"].max(), df["ranking_sistema"].max())
    ax3.plot([1, max_rank], [1, max_rank], "k--", linewidth=0.8, alpha=0.4, label="Coincidencia perfecta")
    ax3.set_xlabel("Ranking del reclutador")
    ax3.set_ylabel("Ranking del sistema")
    ax3.set_title(f"Comparación de rankings\nSpearman ρ = {spearman['rho']:.3f} (p={spearman['p_value']:.3f})", 
                  fontsize=11, fontweight='bold')
    ax3.legend(fontsize=9)
    # Leyenda manual de colores
    from matplotlib.patches import Patch
    legend_elements = [Patch(facecolor='#1D9E75', label='Apto'), Patch(facecolor='#D85A30', label='No apto')]
    ax3.legend(handles=legend_elements, fontsize=9)

    # ── Gráfica 4: Distribución de scores del sistema por afinidad real ──
    ax4 = fig.add_subplot(gs[1, 1])
    if "afinidad" in df.columns:
        grupos = {"alta": "#1D9E75", "media": "#EF9F27", "baja": "#D85A30"}
        for nivel, color in grupos.items():
            subset = df[df["afinidad"] == nivel]["score_sistema"]
            if len(subset) > 0:
                ax4.hist(subset, bins=10, alpha=0.7, color=color, label=f"Afinidad {nivel}", edgecolor="white")
        ax4.legend(fontsize=9)
    else:
        aptos = df[df["label_binario"] == 1]["score_sistema"]
        no_aptos = df[df["label_binario"] == 0]["score_sistema"]
        ax4.hist(aptos, bins=10, alpha=0.7, color="#1D9E75", label="Aptos", edgecolor="white")
        ax4.hist(no_aptos, bins=10, alpha=0.7, color="#D85A30", label="No aptos", edgecolor="white")
        ax4.legend(fontsize=9)
    ax4.set_xlabel("Score del sistema (0-100)")
    ax4.set_ylabel("Frecuencia")
    ax4.set_title("Distribución de scores por grupo", fontsize=11, fontweight='bold')

    # Guardar
    fecha = datetime.now().strftime("%Y%m%d_%H%M")
    nombre_archivo = f"{output_dir}/reporte_evaluacion_{fecha}.png"
    plt.savefig(nombre_archivo, dpi=150, bbox_inches="tight", facecolor="white")
    print(f"✓ Reporte visual guardado: {nombre_archivo}\n")
    plt.close()


# ──────────────────────────────────────────────
# 6. EXPORTAR RESULTADOS A JSON
# ──────────────────────────────────────────────

def exportar_resultados(metricas: dict, spearman: dict, output_dir: str = ".") -> None:
    fecha = datetime.now().strftime("%Y%m%d_%H%M")
    resultados = {
        "fecha_evaluacion": fecha,
        "metricas_clasificacion": {
            "accuracy":  metricas["accuracy"],
            "precision": metricas["precision"],
            "recall":    metricas["recall"],
            "f1_score":  metricas["f1_score"],
            "TP": metricas.get("TP"),
            "FP": metricas.get("FP"),
            "TN": metricas.get("TN"),
            "FN": metricas.get("FN"),
        },
        "correlacion_spearman": {
            "rho": spearman["rho"],
            "p_value": spearman["p_value"],
            "interpretacion": spearman["interpretacion"]
        }
    }
    nombre = f"{output_dir}/resultados_evaluacion_{fecha}.json"
    with open(nombre, "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)
    print(f"✓ Resultados exportados: {nombre}\n")


# ──────────────────────────────────────────────
# 7. FUNCIÓN PRINCIPAL
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Módulo de evaluación — Fase 5 TFM")
    parser.add_argument("--ground_truth",  required=True,  help="CSV con etiquetas del reclutador")
    parser.add_argument("--predicciones",  required=True,  help="CSV con salidas del sistema de IA")
    parser.add_argument("--output_dir",    default=".",    help="Directorio de salida (default: .)")
    parser.add_argument("--varianza",      nargs="+",      type=float,
                        help="Scores del mismo candidato en N ejecuciones (Experimento A)")
    args = parser.parse_args()

    Path(args.output_dir).mkdir(parents=True, exist_ok=True)

    print("\n" + "=" * 55)
    print("  EVALUACIÓN — SISTEMA DE FILTRADO DE CVs CON IA")
    print("=" * 55 + "\n")

    # Cargar datos
    gt, pred, df = cargar_datos(args.ground_truth, args.predicciones)

    # Métricas de clasificación
    metricas = calcular_metricas_clasificacion(df)
    imprimir_metricas(metricas)

    # Correlación de ranking
    spearman = calcular_spearman(df)

    # Consistencia (opcional)
    analizar_consistencia(df, varianza_scores=args.varianza)

    # Visualizaciones
    generar_reporte_visual(df, metricas, spearman, output_dir=args.output_dir)

    # Exportar JSON
    exportar_resultados(metricas, spearman, output_dir=args.output_dir)

    print("Evaluación completada.\n")


# ──────────────────────────────────────────────
# EJEMPLO DE USO PROGRAMÁTICO (sin CLI)
# ──────────────────────────────────────────────

def evaluar_desde_codigo(ground_truth_csv: str, predicciones_csv: str, output_dir: str = "."):
    """
    Alternativa a la CLI para usar el módulo desde un notebook o script.

    Ejemplo:
        from evaluacion_tfm import evaluar_desde_codigo
        evaluar_desde_codigo("ground_truth.csv", "predicciones.csv", output_dir="resultados/")
    """
    gt, pred, df = cargar_datos(ground_truth_csv, predicciones_csv)
    metricas = calcular_metricas_clasificacion(df)
    imprimir_metricas(metricas)
    spearman = calcular_spearman(df)
    analizar_consistencia(df)
    generar_reporte_visual(df, metricas, spearman, output_dir=output_dir)
    exportar_resultados(metricas, spearman, output_dir=output_dir)
    return {"metricas": metricas, "spearman": spearman}


if __name__ == "__main__":
    main()
